import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Navbar from './components/Navbar';
import Slide from './components/Slide';
import Main from './components/Main';
import Modal from './components/Modal';
import Footer from './components/Footer';
import Transitions from './components/Transitions';

function App() {
  return (
    <div>
  <Navbar />
  <Slide />
  <Transitions />
  <Main />
  <Modal />
  <Footer />
    </div>
  );
}

export default App;
