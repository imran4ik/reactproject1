import React, { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';

function StaticExample() {
    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
  return (
    <>
    <Button className='mt-5' variant="primary" onClick={handleShow}>
      Связаться
    </Button>

    <Modal show={show} onHide={handleClose}>
      <Modal.Header closeButton>
        <Modal.Title>Наш номер телефона / gmail</Modal.Title>
      </Modal.Header>
      <Modal.Body>+994504004040, rovshanlankaranski@gmail.az</Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={handleClose}>
          Написать на номер
        </Button>
        <Button variant="primary" onClick={handleClose}>
          Написать на gmail
        </Button>
      </Modal.Footer>
    </Modal>
  </>
  );
}

export default StaticExample;