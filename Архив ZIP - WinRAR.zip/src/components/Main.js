import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';

function OrderingExample() {
  return (
    <Container>
      <Row className='mt-5'>
        <Col xs><Card style={{ width: '18rem' }}>
      <Card.Img variant="top" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTOv66raHuPnN6n2gIPiTbtv85N7Zgp0Hkbw&usqp=CAU" />
      <Card.Body>
        <Card.Title>Пистолет Стечкина</Card.Title>
        <Card.Text>
        Открывает десятку лучших пистолетов в мире автоматический пистолет Стечкина. Он поступил на вооружение советской армии в один год вместе с легендарным пистолетом Макарова, но известно о нем намного меньше.. Высокая себестоимость оружия и некоторые недостатки. Он был тяжелым, громоздким и неудобным в ношении. В боевых условиях ПС не хватало мощности.
        </Card.Text>
      </Card.Body>
    </Card></Col>
        <Col xs={{ order: 12 }}>    <Card style={{ width: '18rem' }}>
      <Card.Img variant="top" src="https://supercoolpics.com/wp-content/uploads/2015/10/052.jpg" />
      <Card.Body>
        <Card.Title>Кольт M1911</Card.Title>
        <Card.Text>
        Это один из старейших пистолетов со столетней историей, что уже делает его лучшим оружием в мире. Более 70 лет он находился на вооружении армии США, пока не уступил итальянской марке Beretta 92. Является самым массовым и известным пистолетом в мире и имеет массу клонов. Недостатки: большие габариты и вес, маленькая емкость магазина.
        </Card.Text>
      </Card.Body>
    </Card></Col>
        <Col xs={{ order: 1 }}>    <Card style={{ width: '18rem' }}>
      <Card.Img variant="top" src="https://supercoolpics.com/wp-content/uploads/2015/10/062.jpg" />
      <Card.Body>
        <Card.Title>Пистолет ТТ</Card.Title>
        <Card.Text>
        ТТ – легендарный пистолет отечественного производства, разработанный в 1930 годах, имеет большую убойную силу и пробивную способность. Это оружие с высокими боевыми и эксплуатационными качествами. Небольшие размеры и вес позволяют скрытое ношение. Простое в обращении и надежное при ведении огня, оно быстро завоевало признание.
        </Card.Text>
      </Card.Body>
    </Card></Col>
      </Row>
    </Container>
  );
}

export default OrderingExample;